/*
 * Azul Systems | Support Team
 * Only for internal use.
 */
package tsp_optimitzar;

/**
 *
 * @author JuanJose
 */

import java.util.List;
import java.util.Random;

public class TSP_Montecarlo extends Thread {

    // Entradas
    private final List<String> lista_nombre_nodos;
    private final float[] v_distancias;
    private final double precision;

    // Resto variables 
    private float minimo = Float.MAX_VALUE;
    private float sumatorio = 0;
    private int[] vRuta = null;
    private final int nNodos;

    // Contructor
    public TSP_Montecarlo(List<String> lista_nombre_nodos, float[] v_distancias, double precision, int nHilos) {
        this.lista_nombre_nodos = lista_nombre_nodos;
        this.nNodos = lista_nombre_nodos.size();
        this.v_distancias = v_distancias;
        this.precision = Math.abs(precision / nHilos);
    }

    @Override
    public void run() {

        // Control parametros correctos
        if (lista_nombre_nodos.size() == Math.sqrt(v_distancias.length)) {
            float[][] t_distancias = conversorVT(v_distancias);
            int[] aux_perm = new int[nNodos];
            int[] perm = new int[nNodos];
            Random rnd = new Random();
            int aux_nNodos = nNodos;
            int cont = 0;
            int res;

            do {
                sumatorio = 0;
                // Busqueda de rutas aleatorias evitando repeticiones de nodos.
                // +1338%
                aux_nNodos = nNodos;
                for (int i = 0; i < nNodos; i++) {
                    aux_perm[i] = i + 1;
                }
                for (int i = 0; i < nNodos; i++) {
                    res = rnd.nextInt(aux_nNodos);
                    perm[i] = aux_perm[res] - 1;
                    aux_perm[res] = aux_perm[aux_nNodos - 1];
                    aux_nNodos--;
                }
                
                sumatorio += t_distancias[perm[nNodos - 1]][perm[0]];
                for (int i = 0; i < (nNodos - 1); i++) {
                    sumatorio += t_distancias[perm[i]][perm[i + 1]];
                    if (sumatorio > minimo) { // +200%
                        break;
                    }
                }
                if (sumatorio < minimo) {
                    minimo = sumatorio;
                    vRuta = perm.clone();
                }
            } while (cont++ < precision);
        }
    }

    public float[][] conversorVT(float[] v_distancias) {
        float[][] t_distancias = new float[nNodos][nNodos];
        int cont = 0;
        for (int i = 0; i < nNodos; i++) {
            for (int j = 0; j < nNodos; j++) {
                t_distancias[j][i] = v_distancias[cont];
                cont++;
            }
        }
        return t_distancias;
    }

    public float getDistancia() {
        return minimo;
    }

    public String getRuta() {
        String ruta = lista_nombre_nodos.get(vRuta[0]) + " - ";
        for (int i = 1; i < nNodos - 1; i++) {
            ruta += lista_nombre_nodos.get(vRuta[i]) + " - ";
        }
        ruta += lista_nombre_nodos.get(vRuta[nNodos - 1]);
        return ruta;
    }
}
